from django.apps import AppConfig


class TraveloutConfig(AppConfig):
    name = 'travelOut'
